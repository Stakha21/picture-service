
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'stakha',
  applicationName: 'picture-service',
  appUid: 'ytqn9BXJ0rxsymPtM0',
  orgUid: 'a501c56d-3d0c-41ce-aa8f-5b03396fc783',
  deploymentUid: '4c478314-589a-462b-b296-b58ae092051a',
  serviceName: 'picture-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'picture-service-dev-singup', timeout: 6 };

try {
  const userHandler = require('./src/user/signup/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.signup, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}